#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/types.h>
#include <linux/slab.h>
#include <linux/sched.h>
#include <linux/string.h>
#include <linux/fs.h>
#include <linux/seq_file.h>
#include <linux/proc_fs.h>


#define FileProc "cpu_200915120"

MODULE_AUTHOR("Pedro César Tay Dubón");
MODULE_DESCRIPTION("Modulo que lista los procesos del sistema.");
MODULE_LICENSE("GPL");

void readChildren(struct seq_file *m, struct task_struct *s);
char process_state(struct task_struct *s);

static int lstree(struct seq_file *f, void *v)
{
    struct task_struct *root = current; 
    seq_printf(f,"===================================================\n");
    seq_printf(f,"Carné 200915120\n");
    seq_printf(f,"Pedro César Tay Dubón\n");
    seq_printf(f,"Fedora 27\n");
    seq_printf(f,"===================================================\n");
    seq_printf(f,"%5s  %20s   %s\n", "PID", "Nombre", "Estado");
    seq_printf(f,"===================================================\n");

    while (root->pid != 1)
        root = root->parent; 
    
    readChildren(f, root);
    return 0;
}

void readChildren(struct seq_file *m, struct task_struct *s)
{
    struct list_head *list;
    struct task_struct *task;     
    seq_printf(m,"%5d  %20s   %c\n", s->pid, s->comm, process_state(s));
                 
    list_for_each(list, &s->children) {        
        task = list_entry(list, struct task_struct, sibling);
        readChildren(m, task);        
    }    
}

char process_state(struct task_struct *state)
{
    if(state->state == TASK_RUNNING){
        return 'R';    
    }else if(state->state == TASK_INTERRUPTIBLE){
        return 'S';
    }else if(state->state == EXIT_ZOMBIE){
        return 'Z';
    }else if(state->state == TASK_STOPPED){
        return 'T';
    }else if(state->state == TASK_UNINTERRUPTIBLE){
        return 'D';
    }else{
        return '-';
    }    
}


static int cpu_open(struct inode *inode, struct file *file)
{
    return single_open(file, lstree, NULL);
}

static const struct file_operations procsinfo_proc_fops = {
    .open       = cpu_open,
    .read       = seq_read,
    .llseek     = seq_lseek,
    .release    = single_release,
};

static int __init start_function(void)
{
    printk(KERN_INFO "Pedro César Tay Dubón.\n");
    /*printk(KERN_INFO "Modulo CPU cargado.\n");*/
    proc_create(FileProc, 0, NULL, &procsinfo_proc_fops); 
    /*printk(KERN_INFO "Instalación de modulo: /proc/%s.\n", FileProc);*/
    return 0;
}

 
static void __exit clean_function(void)
{
    remove_proc_entry(FileProc, NULL); 
    printk(KERN_INFO "Sistemas Operativos 1.\n");
    /*printk(KERN_INFO "Desinstalación de modulo.\n");*/
}
 
module_init(start_function);
module_exit(clean_function);
 


