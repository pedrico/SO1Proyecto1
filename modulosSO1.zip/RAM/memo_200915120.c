#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <asm/uaccess.h>
#include <linux/hugetlb.h>
#include <linux/mm.h>
#include <linux/mman.h>
#include <linux/mmzone.h>
#include <linux/quicklist.h>
#include <linux/swap.h>
#include <linux/swapfile.h>
#include <linux/vmstat.h>
#include <linux/atomic.h>
#include <asm/page.h>
#include <asm/pgtable.h>

#define FileProc "memo_200915120"

MODULE_AUTHOR("Pedro César Tay Dubón");
MODULE_DESCRIPTION("Modulo de información de memoria RAM");
MODULE_LICENSE("GPL");

struct sysinfo i;
unsigned long committed;
unsigned long allowed;

long cached;
unsigned long pages[NR_LRU_LISTS];
int lru;
long unsigned total;
long unsigned libre;
long unsigned ocupada;
long unsigned pocupada;

static int status(struct seq_file *f, void *v){
    #define K(x) ((x) << (PAGE_SHIFT - 10))
    si_meminfo(&i);
    for (lru = LRU_BASE; lru < NR_LRU_LISTS; lru++)
    pages[lru] = global_numa_state(NR_LRU_BASE + lru);    	
    seq_printf(f,"===================================================\n");
    seq_printf(f,"Carné 200915120\n");
    seq_printf(f,"Pedro César Tay Dubón\n");
    seq_printf(f,"Fedora 27\n");
    si_meminfo(&i); 
    seq_printf(f,"Memoria Total: %11lu kB\n",K(i.totalram));
    /*seq_printf(f,"%8lu\n", (i.totalram));*/
    seq_printf(f,"Memoria Libre: %11lu kB\n",K(i.freeram));
    total = 0;
    ocupada = 0;
    pocupada = 0;
    
    total = K(i.totalram);
    libre = K(i.freeram);
    ocupada = total - libre;
    pocupada = ocupada * 100 / total ;
    seq_printf(f,"Memoria ocupada: %9lu kB\n",ocupada);
    seq_printf(f,"%% memoria ocupada: %2lu %%\n",pocupada);

    return 0;
}



static int ram_open(struct inode *inode, struct file *file){
    return single_open(file, status, NULL);
}

static const struct file_operations Meminfo_fops = {
    .owner = THIS_MODULE,
    .open = ram_open,
    .read = seq_read,
    .llseek = seq_lseek,
    .release = single_release,
};


static int __init start_function(void)
{
    printk(KERN_INFO "Carné 200915120.\n");
    proc_create(FileProc, 0, NULL, &Meminfo_fops);
    /*printk(KERN_INFO "Archivo creado en: /proc/%s.\n", FileProc);*/
    return 0;
}

static void __exit clean_function(void)
{
    remove_proc_entry(FileProc, NULL); 
    printk(KERN_INFO "Sistemas Operativos 1.\n");
}
 
module_init(start_function);
module_exit(clean_function);
 


